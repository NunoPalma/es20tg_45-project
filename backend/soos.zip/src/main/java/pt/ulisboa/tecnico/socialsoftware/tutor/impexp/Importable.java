package pt.ulisboa.tecnico.socialsoftware.tutor.impexp;

public interface Importable {
}
