package pt.ulisboa.tecnico.socialsoftware.tutor.tournament.domain;

public class CreatedTournament implements TournamentState {
}
